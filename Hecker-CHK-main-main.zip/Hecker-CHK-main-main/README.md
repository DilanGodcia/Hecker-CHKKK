usar el ngrok. cambiar la ruta en .env
para mayor informacion del bot: https://api.telegram.org/bot8076521376:AAHE9Qxjwt6BpE-wFq8sazjD0fgvxyrApUQ/getWebhookInfo
en powershell en la terminal de VS Code:  curl -F "url=https://4861-191-156-9-61.ngrok-free.app/Hecker-CHK-main/bot.php" https://api.telegram.org/bot8076521376:AAHE9Qxjwt6BpE-wFq8sazjD0fgvxyrApUQ/setWebhook <-- con la nuva ruta de ngrok
usar xampp
