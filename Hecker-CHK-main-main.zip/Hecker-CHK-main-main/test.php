<?php
// test.php

phpinfo();
?>